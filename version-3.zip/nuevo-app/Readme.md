
# Linaje (frontend + backend)

Guía rápida para levantar el backend FastAPI y servir el frontend de linaje. Para más detalle, consulta:
- Backend: [`backend/Readme-backend.md`](backend/Readme-backend.md)
- Frontend: [`frontend/Readme-frontend.md`](frontend/Readme-frontend.md)

## Requisitos
- Python 3.9+

## Instalación de dependencias (backend)
```bash
cd backend
pip install -r requirements.txt
```

## Ejecutar backend
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8001
```
El backend lee los JSON desde `../json/` y expone `http://127.0.0.1:8001`.

## Servir frontend
En otra terminal:
```bash
cd frontend
python -m http.server 8000
```
Abrir en el navegador: http://127.0.0.1:8000

## Variables / configuración
- El frontend usa por defecto `http://127.0.0.1:8001`. Puedes sobreescribir con `window.LINAJE_BACKEND` antes de cargar `app.js`.

## Estructura rápida
- `backend/`: FastAPI + lógica de validación/filtrado de linaje.
- `frontend/`: HTML/CSS/JS del visualizador (Cytoscape).
- `json/`: datos de ejemplo nivel tablas y campos.

## Troubleshooting básico
- CORS/local: sirve siempre el frontend con un servidor (no abrir directo el archivo).
- Si cambias los JSON, puedes llamar a `POST /linaje/reload` o reiniciar el backend.
