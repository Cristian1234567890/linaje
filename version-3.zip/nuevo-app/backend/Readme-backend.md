# Linaje Backend (FastAPI)

Servicio que expone filtros y relaciones de linaje (nivel tablas y nivel campos) consumiendo los JSON locales. funciones principales (normalización, validaciones, cierres upstream/downstream).

## Requisitos
- Python 3.9+
- Instalar dependencias: `pip install -r requirements.txt`
  - fastapi (https://fastapi.tiangolo.com/), uvicorn (https://www.uvicorn.org/), pydantic (https://docs.pydantic.dev/)

## Ejecución local
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8001
```
Los JSON se leen desde `../json/datos-objetivo.json` (tablas) y `../json/datos-objetivo-campos.json` (campos). El frontend usa `http://127.0.0.1:8001` por defecto (configurable vía `window.LINAJE_BACKEND` en el front).

## Endpoints
- `GET /health` → `{ ok: true }`
- `POST /linaje/filters`
  - Body `QueryFilters`: `{ viewMode: "tables"|"fields", zone: "all"|string, table: "all"|string, showAll: bool, hideLz: bool }`
  - Devuelve `{ base_total, zones[] }` con zonas ya procesadas (`zone`, `type`, `startTables`, `destinations`).
- `POST /linaje/records`
  - Body `QueryFilters` (mismo formato).
  - Devuelve `{ total, records[] }` ya validados y filtrados según reglas de negocio.
- `POST /linaje/reload`
  - Fuerza recarga de los JSON desde disco.

## Validaciones y normalización
- `normalize_table/normalize_field`: minúsculas + trim.
- `is_allowed_table`: exige prefijos `s_bani*`, `proceso*`, `resultados*` o zonas `lz.estatico` / `lz.funcion`, y presencia de `.` salvo las zonas lz.
- `is_valid_field`:
  - Acepta `*`.
  - Rechaza palabras reservadas (`RESERVED_FIELD_WORDS`).
  - Números puros solo son válidos si la tabla es `lz.estatico*`.
  - No permite `*` en medio ni otros símbolos; regex: empieza y termina en `[a-z0-9]`, puede tener `_` intermedio (snake_case).
- `sanitize_records`:
  - Marca `valid=false` y `invalid_reason` cuando tabla origen/destino no es permitida o campo inválido (en viewMode `fields` también se rechaza `*`).
  - El frontend solo consume `valid=true`.

## Reglas de negocio (filtrado)
- `hideLz=true` oculta relaciones cuyo `tabla_origen` sea `lz.estatico*` o `lz.funcion*`.
- Zonas (`compute_zones_info`):
  - Agrupa por `tabla_destino`, calcula `destinations` y `startTables`.
  - Tipifica zonas: resultados/proceso/s_bani/lz-estatico/lz-funcion.
- Cierres:
  - Upstream (`compute_upstream_closure_constrained`): desde una tabla destino recorre hacia sus orígenes mientras sean “startable” (resultados/proceso/s_bani/lz.estatico/lz.funcion).
  - Downstream (`compute_downstream_closure`): para zonas `s_*`, recorre origen → destinos.
- /linaje/records:
  - Zonas `s_*`: si `showAll` o sin tabla concreta, toma `startTables` de la zona y recorre downstream; si hay tabla elegida, usa esa como seed downstream.
  - Zonas no `s_*` con `showAll`: recorre upstream desde todas las `destinations` de la zona.
  - Con tabla seleccionada: upstream constrained desde esa tabla destino.

## Estructura de los JSON
Formato común en ambos archivos:
```json
[
  {
    "id": "uuid-o-id",
    "consulta": "create table ...",
    "tabla_origen": "proceso_x.origen",
    "tabla_destino": "resultados_x.destino",
    "campo_origen": "*",
    "campo_destino": "*",
    "transformacion_aplicada": null,
    "recomendaciones": "texto opcional"
  }
]
```
`datos-objetivo.json` es nivel tablas; `datos-objetivo-campos.json` añade linajes campo a campo (respetando las validaciones anteriores).
