from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from pathlib import Path
import json


DATA_DIR = Path(__file__).resolve().parent.parent / "json"
TABLES_FILE = DATA_DIR / "datos-objetivo.json"
FIELDS_FILE = DATA_DIR / "datos-objetivo-campos.json"


app = FastAPI(title="Linaje Backend", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class LinajeRecord(BaseModel):
    id: Optional[str] = None
    consulta: Optional[str] = None
    tabla_origen: Optional[str] = None
    tabla_destino: Optional[str] = None
    campo_origen: Optional[str] = None
    campo_destino: Optional[str] = None
    transformacion_aplicada: Optional[str] = None
    recomendaciones: Optional[str] = None


class QueryFilters(BaseModel):
    viewMode: str = "tables"  # "tables" | "fields"
    zone: str = "all"
    table: str = "all"
    showAll: bool = False
    hideLz: bool = False


# ---------- Logic (ported from frontend) ----------

RESERVED_FIELD_WORDS = {w.lower() for w in [
    'abort','add','add_months','adddate','aggregate','all','alter','analyze','analytic','and','any',
    'appx_median','archive','array','as','asc','authorization','avg','between','bigint','binary',
    'boolean','both','break','bucket','buckets','by','cache','case','cascade','cast','change','char',
    'class','close','cluster','clustered','coalesce','collection','column','columns','comment','compact',
    'compactions','compute','conf','continue','count','create','cross','current','current_date',
    'current_timestamp','cursor','data','database','databases','date','date_add','date_sub','datediff',
    'datetime','day','dayname','dayofmonth','dayofweek','dayofyear','dbproperties','decimal','deferred',
    'delimited','dependency','desc','describe','directories','directory','disable','distinct','distribute',
    'div','double','drop','else','enable','end','escape','escaped','except','exchange','exclusive','exists',
    'explain','extract','extended','external','false','fetch','field','fields','file','fileformat','files',
    'finalize','first','float','floor','following','for','format','from','from_timestamp','from_unixtime',
    'from_utc_timestamp','full','function','functions','grant','group','having','hold','hour','if','ifnull',
    'import','in','incremental','init','initially','inner','inputdriver','inputformat','inpath','insert',
    'int','integer','intersect','interval','into','is','isnull','item','join','key','keys','last','last_day',
    'lateral','left','length','like','limit','lines','load','local','location','lock','locks','log','lower',
    'macro','map','mapjoin','materialized','max','merge','metadata','min','minus','minute','more',
    'months_between','none','nonstrict','not','now','null','nulls','nvl','offset','on','or','order',
    'outer','outputdriver','outputformat','over','overwrite','parquet','partition','partitioned',
    'partitions','percent','power','preceding','primary','procedure','protection','purge','range','read',
    'readonly','real','rebuild','recordreader','recordwriter','recover','regexp_count','regexp_extract',
    'regexp_instr','regexp_like','regexp_replace','regexp_substr','reload','rename','replace','replication',
    'repair','restrict','revoke','rewrite','right','rlike','role','roles','rollback','round','row','rows',
    'schema','schemas','second','select','semi','sequencefile','serde','serdeproperties','server','set',
    'sets','shared','show','skewed','smallint','sort','sqrt','ssl','statistics','stored','streamtable',
    'str_to_timestamp','string','struct','substr','sum','table','tables','tablesample','tblproperties',
    'temporary','terminated','textfile','then','timestamp','timestamp_micros','timestamp_millis',
    'timestamp_seconds','tinyint','to','to_date','to_timestamp','to_unix_timestamp','touch','transform',
    'transaction','transactions','trim','true','trunc','truncate','typeof','unarchive','unbounded','union',
    'unique','unix_timestamp','unlock','unsigned','update','upper','use','using','validate','value','values',
    'variance','varchar','view','views','wait','when','where','while','with','write'
]}

TABLE_PATTERNS = [
    # s_bani___.____, proceso___.____, proceso.____, resultados___.____
    ("s_bani",), ("proceso",), ("resultados",)
]


def normalize_table(value: Optional[str]) -> str:
    return value.strip().lower() if isinstance(value, str) else ""


def normalize_field(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        return value.strip().lower()
    return str(value).strip().lower()


def is_allowed_table(table: str) -> bool:
    if not table:
        return False
    if table.startswith("lz.estatico") or table.startswith("lz.funcion"):
        return True
    # simple check: must contain a dot and start with known prefixes
    if "." not in table:
        return False
    prefix = table.split(".", 1)[0]
    return (
        prefix in {"s_bani", "proceso", "resultados"}
        or prefix.startswith("s_bani")
        or prefix.startswith("resultados")
        or prefix.startswith("proceso")
    )


def is_lz(table: str) -> bool:
    return table.startswith("lz.estatico") or table.startswith("lz.funcion")


def is_startable_table(table: str) -> bool:
    # tablas que pueden usarse como punto de inicio o cierre upstream
    return (
        table.startswith("resultados")
        or table.startswith("proceso")
        or table.startswith("s_bani")
        or table.startswith("lz.estatico")
        or table.startswith("lz.funcion")
    )


def extract_zone(table: str) -> Optional[str]:
    if not table:
        return None
    if table.startswith("lz.estatico"):
        return "lz.estatico"
    if table.startswith("lz.funcion"):
        return "lz.funcion"
    if "." in table:
        return table.split(".", 1)[0]
    return table


def zone_type(zone: str) -> str:
    if not zone:
        return "otro"
    if zone.startswith("resultados"):
        return "resultados"
    if zone.startswith("proceso"):
        return "proceso"
    if zone.startswith("s_bani"):
        return "s_bani"
    if zone.startswith("lz.estatico"):
        return "lz-estatico"
    if zone.startswith("lz.funcion"):
        return "lz-funcion"
    return "otro"


def is_valid_field(field: Optional[str], table_context: Optional[str] = None) -> bool:
    if not field:
        return False
    if field == "*":
        return True
    if field in RESERVED_FIELD_WORDS:
        return False
    # pure numbers: allowed only if coming from lz.estatico context
    if field.replace(".", "", 1).isdigit():
        return bool(table_context and table_context.startswith("lz.estatico"))
    if "*" in field:
        return False
    # regex: starts [a-z0-9], may contain _ in the middle, ends [a-z0-9]
    import re
    if not re.match(r"^[a-z0-9](?:[a-z0-9_]*[a-z0-9])?$", field):
        return False
    # enforce snake_case groups
    if not re.match(r"^[a-z0-9]+(?:_[a-z0-9]+)*$", field):
        return False
    return True


def sanitize_records(records: List[Dict[str, Any]], level: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for rec in records:
        td = normalize_table(rec.get("tabla_destino"))
        to = normalize_table(rec.get("tabla_origen"))
        cd = normalize_field(rec.get("campo_destino"))
        co = normalize_field(rec.get("campo_origen"))

        valid = True
        reason = None

        if not is_allowed_table(td) or not is_allowed_table(to):
            valid = False; reason = "tabla no permitida"

        if not cd:
            valid = False; reason = reason or "campo_destino nulo"

        if level == "fields":
            if cd == "*":
                valid = False; reason = reason or "usa '*' a nivel campos"
            if not is_valid_field(cd, td):
                valid = False; reason = reason or "campo_destino invalido"
            if not co or not is_valid_field(co, to):
                valid = False; reason = reason or "campo_origen invalido"
        else:
            if not is_valid_field(cd, td):
                valid = False; reason = reason or "campo_destino invalido"
            if co and not is_valid_field(co, to):
                valid = False; reason = reason or "campo_origen invalido"

        new_rec = dict(rec)
        new_rec.update({
            "tabla_destino": td,
            "tabla_origen": to,
            "campo_destino": cd,
            "campo_origen": co,
            "valid": valid,
            "invalid_reason": reason,
        })
        out.append(new_rec)
    return out


def compute_zones_info(records: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    zones: Dict[str, Dict[str, Any]] = {}
    for r in records:
        td = r.get("tabla_destino")
        to = r.get("tabla_origen")

        # Siempre considerar la zona del destino
        dest_zone = extract_zone(td)
        if dest_zone:
            entry = zones.setdefault(dest_zone, {
                "zone": dest_zone,
                "type": zone_type(dest_zone),
                "startTables": set(),
                "destinations": set(),
            })
            entry["destinations"].add(td)
            if is_startable_table(td):
                entry["startTables"].add(td)

        # Para zonas s_* también considerar la zona de origen como seleccionable
        origin_zone = extract_zone(to)
        if origin_zone and origin_zone.startswith("s_"):
            entry_o = zones.setdefault(origin_zone, {
                "zone": origin_zone,
                "type": zone_type(origin_zone),
                "startTables": set(),
                "destinations": set(),
            })
            if to:
                entry_o["startTables"].add(to)      # tablas origen seleccionables
            if td:
                entry_o["destinations"].add(td)     # destinos inmediatos desde ese origen
    # convert sets to sorted lists
    for k, v in zones.items():
        v["startTables"] = sorted(v["startTables"])  # type: ignore
        v["destinations"] = sorted(v["destinations"])  # type: ignore
    return zones


def compute_upstream_closure_constrained(start_table: str, records: List[Dict[str, Any]], hide_lz: bool) -> set:
    incoming_by_dest: Dict[str, List[Dict[str, Any]]] = {}
    for r in records:
        if hide_lz and is_lz(r.get("tabla_origen") or ""):
            continue
        dest = r.get("tabla_destino") or ""
        incoming_by_dest.setdefault(dest, []).append(r)
    closure = {start_table}
    stack = [start_table]
    while stack:
        dest = stack.pop()
        incoming = incoming_by_dest.get(dest, [])
        for edge in incoming:
            origin = edge.get("tabla_origen")
            if not origin:
                continue
            if origin not in closure:
                closure.add(origin)
                if is_startable_table(origin):
                    stack.append(origin)
    return closure


def compute_downstream_closure(start_table: str, records: List[Dict[str, Any]], hide_lz: bool) -> set:
    """Recorre hacia adelante: origen -> destinos."""
    outgoing_by_origin: Dict[str, List[Dict[str, Any]]] = {}
    for r in records:
        if hide_lz and is_lz(r.get("tabla_origen") or ""):
            continue
        origin = r.get("tabla_origen") or ""
        outgoing_by_origin.setdefault(origin, []).append(r)

    closure = {start_table}
    stack = [start_table]
    while stack:
        origin = stack.pop()
        for edge in outgoing_by_origin.get(origin, []):
            dest = edge.get("tabla_destino")
            if not dest:
                continue
            if dest not in closure:
                closure.add(dest)
                stack.append(dest)
    return closure


# ---------- Data loading ----------

_TABLES: List[Dict[str, Any]] = []
_FIELDS: List[Dict[str, Any]] = []
_SAN_TABLES: List[Dict[str, Any]] = []
_SAN_FIELDS: List[Dict[str, Any]] = []


def _load_files() -> None:
    global _TABLES, _FIELDS, _SAN_TABLES, _SAN_FIELDS
    if not TABLES_FILE.exists() or not FIELDS_FILE.exists():
        raise FileNotFoundError("Archivos JSON no encontrados en nuevo-app/json/")
    _TABLES = json.loads(TABLES_FILE.read_text(encoding="utf-8"))
    _FIELDS = json.loads(FIELDS_FILE.read_text(encoding="utf-8"))
    _SAN_TABLES = sanitize_records(_TABLES, "tables")
    _SAN_FIELDS = sanitize_records(_FIELDS, "fields")


@app.on_event("startup")
def on_startup():
    _load_files()


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/linaje/filters")
def get_filters(payload: QueryFilters):
    source = _SAN_TABLES if payload.viewMode == "tables" else _SAN_FIELDS
    # base records for filters: only hideLz applies
    base = [r for r in source if r.get("valid") and not (payload.hideLz and is_lz(r.get("tabla_origen") or ""))]
    zones = compute_zones_info(base)
    # order zones for front
    ordered = sorted(zones.values(), key=lambda z: ("resultados,proceso,s_bani,lz-estatico,lz-funcion,otro".split(",").index(z["type"]) if z["type"] in {"resultados","proceso","s_bani","lz-estatico","lz-funcion","otro"} else 99, z["zone"]))
    return {
        "base_total": len(base),
        "zones": ordered,
    }


@app.post("/linaje/records")
def get_records(payload: QueryFilters):
    source = _SAN_TABLES if payload.viewMode == "tables" else _SAN_FIELDS
    # base records for total
    base = [r for r in source if r.get("valid") and not (payload.hideLz and is_lz(r.get("tabla_origen") or ""))]

    # showAll debe ignorar tabla concreta: resetea a "all" para zona
    table_sel = "all" if payload.showAll else payload.table

    zones_map = compute_zones_info(base)

    # Caso especial zonas s_*: recorrer downstream desde las tablas origen de la zona (o la tabla seleccionada)
    if payload.zone and payload.zone.startswith("s_"):
        seeds = []
        if table_sel != "all":
            seeds = [table_sel]
        else:
            info = zones_map.get(payload.zone)
            seeds = list(info.get("startTables", [])) if info else []
        closure = set()
        for seed in seeds:
            closure |= compute_downstream_closure(seed, base, payload.hideLz)
        recs = [r for r in base if (r.get("tabla_origen") in closure)]
        return {"total": len(base), "records": recs}

    # showAll en zonas no s_: recorrer upstream desde todas las tablas de la zona
    if payload.showAll and payload.zone not in ("all", "select"):
        info = zones_map.get(payload.zone)
        seeds = list(info.get("destinations", [])) if info else []
        closure = set()
        for seed in seeds:
            closure |= compute_upstream_closure_constrained(seed, base, payload.hideLz)
        recs = [r for r in base if (r.get("tabla_destino") in closure)]
        return {"total": len(base), "records": recs}

    # if specific table selected -> use constrained upstream closure
    if table_sel and table_sel != "all":
        closure = compute_upstream_closure_constrained(table_sel, base, payload.hideLz)
        recs = [r for r in base if (r.get("tabla_destino") in closure)]
    else:
        # filter by zone and showAll logic
        def rec_ok(r: Dict[str, Any]) -> bool:
            dest_zone = extract_zone(r.get("tabla_destino") or "")
            if payload.zone != "all" and payload.zone != "select" and dest_zone != payload.zone:
                return False
            if payload.zone == "all":
                if table_sel != "all":
                    return r.get("tabla_destino") == table_sel
                return is_startable_table(r.get("tabla_destino") or "")
            if payload.showAll:
                return True  # ya cubierto arriba, pero fallback
            if table_sel != "all":
                return r.get("tabla_destino") == table_sel
            return is_startable_table(r.get("tabla_destino") or "")

        recs = [r for r in base if rec_ok(r)]

    return {
        "total": len(base),
        "records": recs,
    }


@app.post("/linaje/reload")
def reload_data():
    _load_files()
    return {"reloaded": True}
