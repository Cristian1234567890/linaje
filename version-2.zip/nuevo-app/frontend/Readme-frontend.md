# Linaje Frontend (viz)

Frontend en HTML/CSS/JS que consume el backend FastAPI para visualizar linaje a nivel tablas y campos.

## Estructura
- `index.html`: layout, filtros (vista, zona, tabla, showAll, hideLz, layout), y canvas Cytoscape.
- `styles.css`: estilos del layout, dropdowns con buscador, leyendas y temas.
- `app.js`: lógica de interacción y render (Cytoscape).

## Dependencias (CDN)
- Bootstrap 5 (CSS/JS) para dropdown y estilos base. Docs: https://getbootstrap.com/
- Cytoscape + cytoscape-dagre para el grafo. Docs: https://js.cytoscape.org/ y https://github.com/cytoscape/cytoscape.js-dagre
- Tippy.js + cytoscape-popper para tooltips. Docs: https://atomiks.github.io/tippyjs/ y https://github.com/cytoscape/cytoscape.js-popper

## Configuración
- Backend por defecto: `http://127.0.0.1:8001` (configurable con `window.LINAJE_BACKEND` antes de cargar `app.js`).
- Servir la carpeta `frontend` con un servidor estático (ej: `python -m http.server 8000`) para evitar CORS al abrir local.

## Filtros
- Tipo de vista: `Nivel tablas` / `Nivel campos`.
- Zona: dropdown con buscador; se carga desde `/linaje/filters`.
- Tabla: dropdown con buscador; depende de la zona seleccionada. En zonas `s_*` muestra las tablas origen de esa zona.
- Mostrar todas las tablas de la zona: en zonas `resultados/proceso` recorre upstream; en zonas `s_*` recorre downstream.
- Ocultar orígenes lz.estatico / lz.funcion: filtra los records antes de graficar.
- Layout: columnas por zona (custom) o dagre (flujo libre).

## Flujo de datos
1. Al cargar, llama `/linaje/filters` para poblar zonas.
2. Al seleccionar zona/tabla o cambiar flags, llama `/linaje/records` con `QueryFilters`.
3. Se filtran sólo registros `valid=true` que devuelve el backend.
4. Grafo:
   - Vista tablas: nodos por tabla, agrupados por zona; aristas muestran relación origen→destino.
   - Vista campos: nodos de tabla y de campo; aristas por campo con tooltip y detalle.

## Interacciones
- Dropdowns con buscador: mantienen la selección aun si se filtra y se cierra sin elegir; al cerrar se limpia el texto del buscador.
- Reset: limpia selección (zona “Selecciona una zona”, tabla “Selecciona una zona”) y borra el grafo.
- Tooltips en aristas: muestran origen.destino y transformación.
- Panel de Detalles: al hacer clic en tabla/campo/arista muestra info (transformaciones, recomendaciones, consultas).

## Validaciones aplicadas en frontend
El frontend ya no valida archivos; confía en `valid=true` del backend.

## Desarrollo rápido
```bash
# En una terminal, backend
uvicorn main:app --reload --port 8001

# En otra, servir frontend
cd frontend
python -m http.server 8000
# Abrir http://127.0.0.1:8000
```
